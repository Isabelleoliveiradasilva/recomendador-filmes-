// romance, comedia, açao

// minha mae é uma peça , +12, comedia
// , LIVRE, fantasia, aventura
// as aventuras de pi, 10, drama, fantasia, aventura
// depois da chuva, 10, drama
// guardiões da galáxia, 12, fantasia, aventura
// ladrões de bicicleta, 12, drama
// o menino que descobriu o vento, 14, drama



function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}